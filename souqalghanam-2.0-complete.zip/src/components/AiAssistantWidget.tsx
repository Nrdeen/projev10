import { useCallback, useEffect, useRef, useState } from 'react';
import {
  MapPin,
  MessageSquareText,
  Send,
  ShieldCheck,
  Sparkles,
  Trash2,
  X,
} from 'lucide-react';
import { api } from '../lib/api';
import { formatPriceSar } from '../lib/format';
import type { AiChatHistoryItem, AiListingCard, AiUsageSnapshot } from '../types/marketplace';
import { SafeImage } from './SafeImage';

interface ChatMessageItem {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  cards?: AiListingCard[];
  suggestedFollowUps?: string[];
  isError?: boolean;
}

interface AiAssistantWidgetProps {
  onSelectListing: (listingId: string) => void;
  userId?: string | null;
}

const INITIAL_PROMPTS = [
  'أبي جذعان نعيمي بالرياض تحت 2000',
  'كم أسعار الحري والنجدي؟',
  'كيف أقدم عرض سعر (سوم)؟',
];

const WELCOME_MESSAGE: ChatMessageItem = {
  id: 'welcome',
  role: 'assistant',
  content:
    'حياك الله في سوق الغنم 2.0! اسألني بلهجتك عن الإعلانات المتوفرة حسب السلالة والمنطقة والسعر، أو عن دليل السلالات وطريقة تقديم السوم.',
  suggestedFollowUps: INITIAL_PROMPTS,
};

export function AiAssistantWidget({ onSelectListing, userId }: AiAssistantWidgetProps) {
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState<ChatMessageItem[]>([WELCOME_MESSAGE]);
  const [input, setInput] = useState('');
  const [sending, setSending] = useState(false);
  const [maxMessageLength, setMaxMessageLength] = useState(600);
  const [usage, setUsage] = useState<AiUsageSnapshot | null>(null);
  const [enabled, setEnabled] = useState(true);

  const listEndRef = useRef<HTMLDivElement | null>(null);
  const inputRef = useRef<HTMLInputElement | null>(null);
  const launcherRef = useRef<HTMLButtonElement | null>(null);

  const fetchStatus = useCallback(async () => {
    try {
      const status = await api.getAiStatus();
      setEnabled(status.enabled);
      setMaxMessageLength(status.maxMessageLength || 600);
      setUsage(status.usage);
    } catch {
      // Keep defaults if status check is temporarily unreachable
    }
  }, []);

  useEffect(() => {
    if (open) {
      void fetchStatus();
      const timer = window.setTimeout(() => {
        inputRef.current?.focus();
      }, 60);
      return () => window.clearTimeout(timer);
    }
  }, [open, userId, fetchStatus]);

  useEffect(() => {
    if (!open) return;
    listEndRef.current?.scrollIntoView({ behavior: 'smooth', block: 'end' });
  }, [messages, open, sending]);

  useEffect(() => {
    if (!open) return;
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        setOpen(false);
        launcherRef.current?.focus();
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [open]);

  const sendMessage = async (rawText: string) => {
    const trimmed = rawText.trim();
    if (!trimmed || sending) return;

    const userMsg: ChatMessageItem = {
      id: `usr_${Date.now()}`,
      role: 'user',
      content: trimmed,
    };

    const history: AiChatHistoryItem[] = messages
      .filter((m) => m.id !== 'welcome' && !m.isError)
      .slice(-6)
      .map((m) => ({ role: m.role, content: m.content }));

    setMessages((prev) => [...prev, userMsg]);
    setInput('');
    setSending(true);

    try {
      const res = await api.sendAiChat({ message: trimmed, history });
      setUsage(res.usage);
      setMessages((prev) => [
        ...prev,
        {
          id: `ai_${Date.now()}`,
          role: 'assistant',
          content: res.reply,
          cards: res.cards,
          suggestedFollowUps: res.suggestedFollowUps,
        },
      ]);
    } catch (err: any) {
      setMessages((prev) => [
        ...prev,
        {
          id: `err_${Date.now()}`,
          role: 'assistant',
          content: err?.message || 'تعذر الحصول على رد الآن، يرجى المحاولة بعد لحظات.',
          isError: true,
        },
      ]);
    } finally {
      setSending(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    void sendMessage(input);
  };

  const handleCardClick = (listingId: string) => {
    onSelectListing(listingId);
    if (window.innerWidth < 640) {
      setOpen(false);
    }
  };

  const handleResetChat = () => {
    setMessages([WELCOME_MESSAGE]);
    inputRef.current?.focus();
  };

  if (!enabled) return null;

  return (
    <>
      {!open && (
        <button
          ref={launcherRef}
          type="button"
          onClick={() => setOpen(true)}
          aria-label="فتح مساعد سوق الغنم الذكي"
          data-testid="ai-assistant-launcher"
          className="fixed bottom-4 left-4 sm:bottom-6 sm:left-6 z-40 inline-flex items-center gap-2.5 px-4 py-3 rounded-2xl bg-[var(--color-green)] hover:bg-[var(--color-green-hover)] text-white shadow-lg border border-[var(--color-gold)]/45 transition-all cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[var(--color-gold)]"
        >
          <span className="w-8 h-8 rounded-xl bg-[var(--color-gold)]/20 text-[var(--color-gold)] flex items-center justify-center shrink-0">
            <Sparkles size={18} aria-hidden="true" />
          </span>
          <span className="text-sm font-bold whitespace-nowrap">المساعد الذكي</span>
        </button>
      )}

      {open && (
        <section
          role="dialog"
          aria-modal="false"
          aria-label="مساعد سوق الغنم الذكي"
          data-testid="ai-assistant-dialog"
          dir="rtl"
          className="fixed inset-2 sm:inset-auto sm:bottom-5 sm:left-5 z-50 sm:w-[410px] sm:max-w-[calc(100vw-2.5rem)] sm:h-[590px] sm:max-h-[calc(100vh-3rem)] flex flex-col bg-[var(--color-surface)] text-[var(--color-ink)] rounded-2xl border border-[var(--color-border)] shadow-2xl overflow-hidden"
        >
          {/* Header */}
          <header className="px-4 py-3 bg-[var(--color-green)] text-white flex items-center justify-between gap-2 shrink-0 border-b border-[var(--color-gold)]/30">
            <div className="flex items-center gap-2.5 min-w-0">
              <div className="w-9 h-9 rounded-xl bg-[var(--color-gold)]/20 text-[var(--color-gold)] flex items-center justify-center shrink-0">
                <MessageSquareText size={19} aria-hidden="true" />
              </div>
              <div className="min-w-0">
                <h2 className="font-display text-sm font-extrabold truncate">
                  مساعد سوق الغنم الذكي
                </h2>
                <p className="text-[11px] text-white/80 truncate">
                  بحث فوري في الإعلانات ودليل السلالات
                </p>
              </div>
            </div>
            <div className="flex items-center gap-1 shrink-0">
              <button
                type="button"
                onClick={handleResetChat}
                aria-label="بدء محادثة جديدة"
                title="محادثة جديدة"
                className="w-9 h-9 rounded-lg flex items-center justify-center text-white/80 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
              >
                <Trash2 size={16} aria-hidden="true" />
              </button>
              <button
                type="button"
                onClick={() => {
                  setOpen(false);
                  launcherRef.current?.focus();
                }}
                aria-label="إغلاق المساعد الذكي"
                className="w-9 h-9 rounded-lg flex items-center justify-center text-white/80 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
              >
                <X size={18} aria-hidden="true" />
              </button>
            </div>
          </header>

          {/* Messages */}
          <div
            className="flex-1 overflow-y-auto p-3.5 space-y-3.5 bg-[var(--color-cream)]/45"
            aria-live="polite"
          >
            {messages.map((msg) => (
              <div
                key={msg.id}
                className={`flex flex-col gap-2 ${
                  msg.role === 'user' ? 'items-start' : 'items-end'
                }`}
              >
                <div
                  className={`max-w-[92%] rounded-2xl px-3.5 py-2.5 text-sm leading-relaxed whitespace-pre-line break-words ${
                    msg.role === 'user'
                      ? 'bg-[var(--color-green)] text-white rounded-tr-sm'
                      : msg.isError
                      ? 'bg-red-50 dark:bg-red-950/40 text-red-800 dark:text-red-200 border border-red-200 dark:border-red-900 rounded-tl-sm'
                      : 'bg-[var(--color-surface)] text-[var(--color-ink)] border border-[var(--color-border)] rounded-tl-sm shadow-xs'
                  }`}
                >
                  {msg.content}
                </div>

                {/* Clickable Listing Cards */}
                {msg.cards && msg.cards.length > 0 && (
                  <div className="w-full space-y-2" data-testid="ai-listing-cards">
                    {msg.cards.map((card) => (
                      <button
                        key={card.id}
                        type="button"
                        onClick={() => handleCardClick(card.id)}
                        data-testid={`ai-listing-card-${card.id}`}
                        className="w-full text-right bg-[var(--color-surface)] hover:bg-[var(--color-cream)] border border-[var(--color-border)] hover:border-[var(--color-green-ink)]/40 rounded-xl p-2.5 flex items-center gap-3 transition-colors cursor-pointer shadow-xs"
                      >
                        <div className="w-16 h-16 rounded-lg overflow-hidden bg-[var(--color-cream)] shrink-0 border border-[var(--color-border)]">
                          {card.imageUrl ? (
                            <SafeImage
                              src={card.imageUrl}
                              alt={card.title}
                              width={64}
                              height={64}
                              className="w-full h-full object-cover"
                            />
                          ) : (
                            <div className="w-full h-full flex items-center justify-center text-[11px] text-[var(--color-muted)]">
                              صورة
                            </div>
                          )}
                        </div>
                        <div className="flex-1 min-w-0 space-y-1">
                          <div className="text-xs font-bold text-[var(--color-ink)] line-clamp-1">
                            {card.title}
                          </div>
                          <div className="flex items-center gap-2 text-[11px] text-[var(--color-muted)] flex-wrap">
                            <span className="inline-flex items-center gap-1">
                              <MapPin size={11} aria-hidden="true" />
                              {[card.regionName, card.city].filter(Boolean).join(' - ')}
                            </span>
                            {card.breedName && <span>• {card.breedName}</span>}
                            {card.vaccinated && <span>• محصن</span>}
                          </div>
                          <div className="flex items-center justify-between gap-2 pt-0.5">
                            <span className="text-xs font-extrabold text-[var(--color-green-ink)] tabular-nums">
                              {formatPriceSar(card.priceAmount)}
                            </span>
                            <span className="inline-flex items-center gap-1 text-[11px] text-[var(--color-muted)] truncate">
                              {card.sellerVerified && (
                                <ShieldCheck
                                  size={12}
                                  className="text-[var(--color-green-ink)] shrink-0"
                                  aria-hidden="true"
                                />
                              )}
                              <span className="truncate">{card.sellerDisplayName}</span>
                            </span>
                          </div>
                        </div>
                      </button>
                    ))}
                  </div>
                )}

                {/* Quick Follow-ups */}
                {msg.suggestedFollowUps && msg.suggestedFollowUps.length > 0 && (
                  <div className="w-full flex flex-wrap gap-1.5 pt-0.5">
                    {msg.suggestedFollowUps.map((promptText) => (
                      <button
                        key={promptText}
                        type="button"
                        disabled={sending}
                        onClick={() => void sendMessage(promptText)}
                        className="text-[11px] font-medium px-2.5 py-1.5 rounded-lg border border-[var(--color-border)] bg-[var(--color-surface)] hover:bg-[var(--color-cream-hover)] text-[var(--color-ink)] transition-colors cursor-pointer disabled:opacity-50 text-right"
                      >
                        {promptText}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            ))}

            {sending && (
              <div className="flex justify-end">
                <div className="px-3.5 py-2 rounded-2xl rounded-tl-sm bg-[var(--color-surface)] border border-[var(--color-border)] text-xs text-[var(--color-muted)]">
                  جاري البحث وتجهيز الرد...
                </div>
              </div>
            )}
            <div ref={listEndRef} />
          </div>

          {/* Footer Input */}
          <form
            onSubmit={handleSubmit}
            className="p-3 bg-[var(--color-surface)] border-t border-[var(--color-border)] space-y-2 shrink-0"
          >
            <div className="flex items-center gap-2">
              <input
                ref={inputRef}
                type="text"
                value={input}
                maxLength={maxMessageLength}
                onChange={(e) => setInput(e.target.value)}
                placeholder="اكتب طلبك هنا (مثلاً: أبي جذعان نعيمي بالرياض)..."
                aria-label="رسالة المساعد الذكي"
                data-testid="ai-assistant-input"
                className="flex-1 min-w-0 px-3 py-2.5 rounded-xl border border-[var(--color-border)] bg-[var(--color-cream)]/40 text-sm text-[var(--color-ink)] placeholder:text-[var(--color-muted)] focus:outline-none focus:border-[var(--color-green-ink)]"
              />
              <button
                type="submit"
                disabled={sending || !input.trim()}
                aria-label="إرسال للمساعد"
                data-testid="ai-assistant-send"
                className="w-10 h-10 rounded-xl bg-[var(--color-green)] hover:bg-[var(--color-green-hover)] text-white flex items-center justify-center shrink-0 transition-colors cursor-pointer disabled:opacity-45 disabled:cursor-not-allowed"
              >
                <Send size={17} aria-hidden="true" />
              </button>
            </div>
            <div className="flex items-center justify-between text-[11px] text-[var(--color-muted)] px-0.5">
              <span>
                {usage
                  ? `المتبقي اليوم: ${usage.remainingToday} من ${usage.dailyLimit}`
                  : 'استجابات فورية من إعلانات المنصة'}
              </span>
              <span className="tabular-nums">
                {input.length}/{maxMessageLength}
              </span>
            </div>
          </form>
        </section>
      )}
    </>
  );
}
